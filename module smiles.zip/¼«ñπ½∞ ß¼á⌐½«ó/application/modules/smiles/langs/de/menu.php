<?php
//en
$install_lang["admin_menu_content_items_add_ons_items_smiles_menu_item"] = "Smiles";
$install_lang["admin_menu_content_items_add_ons_items_smiles_menu_item_tooltip"] = "Upload and re-order the images";
$install_lang["admin_smiles_menu_smiles_list_item"] = "Smiles list";
$install_lang["admin_smiles_menu_smiles_settings"] = "Settings";
