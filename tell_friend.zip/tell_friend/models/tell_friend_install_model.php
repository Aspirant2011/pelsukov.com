<?php
/**
* Comments install model
*
* @package PG_Dating
* @subpackage application
* @category	modules
* @copyright Pilot Group <http://www.pilotgroup.net/>
* @author Dmitry Popenov
* @version $Revision: 2 $ $Date: 2013-01-30 10:50:07 +0400 $
**/

class Tell_friend_install_model extends Model
{
	private $CI;
	
	private $menu = array(
		'user_top_menu' => array(
			'action' => 'none',
			'items' => array(
				'user-menu-communication' => array(
					'action' => 'none',
					'items' => array(
						'tell_friend_menu_item' => array('action' => 'create', 'link' => 'tell_friend/index', 'status' => 1, 'sorter' => 10),
					),
				),
			),
		),
	);
	protected $notifications = array(
		'notifications' => array(
			array("gid"=>"tell_a_friend", "template"=>"tell_a_friend", "send_type"=>"simple"),
		),
		'templates' => array(
			array('gid' => 'tell_a_friend', 'name' => 'Tell a friend', 'vars' => array('refer_block', 'subject', 'message'), 'content_type' => 'html'),
		),
	);
	
	/**
	 * Constructor
	 *
	 * @return Install object
	 */
	function __construct()
	{
		parent::Model();
		$this->CI = & get_instance();
	}

	public function install_menu() {
		$this->CI->load->helper('menu');

		foreach($this->menu as $gid => $menu_data){
			$this->menu[$gid]['id'] = linked_install_set_menu($gid, $menu_data['action'], $menu_data['name']);
			linked_install_process_menu_items($this->menu, 'create', $gid, 0, $this->menu[$gid]['items']);
		}
	}

	public function install_menu_lang_update($langs_ids = null) {
		if(empty($langs_ids)) return false;
		$langs_file = $this->CI->Install_model->language_file_read('tell_friend', 'menu', $langs_ids);

		if(!$langs_file) { log_message('info', 'Empty menu langs data'); return false; }

		$this->CI->load->helper('menu');

		foreach($this->menu as $gid => $menu_data){
			linked_install_process_menu_items($this->menu, 'update', $gid, 0, $this->menu[$gid]['items'], $gid, $langs_file);
		}
		return true;
	}

	public function install_menu_lang_export($langs_ids) {
		if(empty($langs_ids)) return false;
		$this->CI->load->helper('menu');

		$return = array();
		foreach($this->menu as $gid => $menu_data){
			$temp = linked_install_process_menu_items($this->menu, 'export', $gid, 0, $this->menu[$gid]['items'], $gid, $langs_ids);
			$return = array_merge($return, $temp);
		}
		return array( 'menu' => $return );
	}

	public function deinstall_menu() {
		$this->CI->load->helper('menu');
		foreach($this->menu as $gid => $menu_data){
			if($menu_data['action'] == 'create'){
				linked_install_set_menu($gid, 'delete');
			}else{
				linked_install_delete_menu_items($gid, $this->menu[$gid]['items']);
			}
		}
	}
	/**
	 * Install tell_friend links
	 */
	public function install_tell_friend(){
		///// add tell_friend module
		$this->CI->load->model("tell_friend/models/Banner_group_model");
		$this->CI->Banner_group_model->set_module("tell_friend", "Tell_friend_model", "_banner_available_pages");
		$this->add_tell_friend();
	}

	/**
	 * Import tell_friend languages
	 */
	public function install_tell_friend_lang_update(){
		$lang_ids = array_keys($this->CI->pg_language->languages);
		$lang_id = $this->CI->pg_language->get_default_lang_id();
 		$lang_data[$lang_id] = "Tell friend pages";
		$this->CI->pg_language->pages->set_string_langs("tell_friend", "tell_friend_group_tell_friend_groups", $lang_data, $lang_ids);
	}

	/**
	 * Unistall tell_friend links
	 */
	public function deinstall_tell_friend(){
		// delete tell_friend module
		$this->CI->load->model("tell_friend/models/Banner_group_model");
		$this->CI->Banner_group_model->delete_module("tell_friend");
		$this->remove_tell_friend();
	}

	/**
	 * Add default tell_friend
	 */
	public function add_tell_friend(){
		$this->CI->load->model("Users_model");
		$this->CI->load->model("tell_friend/models/Banner_group_model");
		$this->CI->load->model("tell_friend/models/Banner_place_model");

		$group_attrs = array(
			'date_created' => date("Y-m-d H:i:s"),
			'date_modified' => date("Y-m-d H:i:s"),
			'price' => 1,
			'gid' => 'tell_friend_groups',
			'name' => 'Tell friend pages'
		);
		$group_id = $this->CI->Banner_group_model->create_unique_group($group_attrs);
		$all_places = $this->CI->Banner_place_model->get_all_places();
		if($all_places){
			foreach($all_places  as $key=>$value){
				$this->CI->Banner_place_model->save_place_group($value['id'], $group_id);
			}
		}

		///add pages in group
		$this->CI->load->model("Tell_friend_model");
		$pages = $this->CI->Tell_friend_model->_banner_available_pages();
		if($pages){
			foreach($pages  as $key => $value){
				$page_attrs = array(
					"group_id" => $group_id,
					"name" => $value["name"],
					"link" => $value["link"],
				);
				$this->CI->Banner_group_model->add_page($page_attrs);
			}
		}
	}

	/**
	 * Remove tell_friend
	 */
	public function remove_tell_friend(){
		$this->CI->load->model("tell_friend/models/Banner_group_model");
		$group_id = $this->CI->Banner_group_model->get_group_id_by_gid("tell_friend_groups");
		$this->CI->Banner_group_model->delete($group_id);
	}
	
	/**
	 * Install notifications of tell_friend
	 * 
	 * @return void
	 */
	public function install_notifications(){
		// add notification
		$this->CI->load->model("Notifications_model");
		$this->CI->load->model("notifications/models/Templates_model");

		$templates_ids = array();

		foreach((array)$this->notifications["templates"] as $template_data){
			if(is_array($template_data["vars"])) $template_data["vars"] = implode(", ", $template_data["vars"]);			
			$validate_data = $this->CI->Templates_model->validate_template(null, $template_data);
			if(!empty($validate_data["errors"])) continue;
			$templates_ids[$template_data['gid']] = $this->CI->Templates_model->save_template(null, $validate_data["data"]);			
		}
		
		foreach((array)$this->notifications["notifications"] as $notification_data){
			if(!isset($templates_ids[$notification_data["template"]])){
				 $template = $this->CI->Templates_model->get_template_by_gid($notification_data["template"]);
				 $templates_ids[$notification_data["template"]] = $template["id"];
			}
			$notification_data["id_template_default"] = $templates_ids[$notification_data["template"]];
			$validate_data = $this->CI->Notifications_model->validate_notification(null, $notification_data);
			if(!empty($validate_data["errors"])) continue;
			$this->CI->Notifications_model->save_notification(null, $validate_data["data"], $lang_data);
		}
	}
	
	/**
	 * Import notifiactions languages of tell_friend
	 * 
	 * @param array $langs_ids languages identifiers
	 * @return void
	 */
	public function install_notifications_lang_update($langs_ids=null){
		if(empty($langs_ids)) return false;
		$this->CI->load->model("Notifications_model");
		
		$langs_file = $this->CI->Install_model->language_file_read("tell_friend", "notifications", $langs_ids);
		if(!$langs_file){log_message("info", "Empty notifications langs data");return false;}
		
		$this->CI->Notifications_model->update_langs($this->notifications, $langs_file, $langs_ids);
		return true;
	}
	
	/**
	 * Export notifications languages of tell_friend
	 * 
	 * @param array $langs_ids languages identifiers
	 * @return array
	 */
	public function install_notifications_lang_export($langs_ids=null){
		$this->CI->load->model("Notifications_model");
		$langs = $this->CI->Notifications_model->export_langs($this->notifications, $langs_ids);
		return array("notifications" => $langs);
	}
	
	/**
	 * Unistall notifacations data of tell_friend
	 * 
	 * @return array
	 */
	public function deinstall_notifications(){
		$this->CI->load->model("Notifications_model");
		$this->CI->load->model("notifications/models/Templates_model");
		
		foreach((array)$this->notifications["notifications"] as $notification_data){
			$this->CI->Notifications_model->delete_notification_by_gid($notification_data["gid"]);
		}
		
		foreach((array)$this->notifications["templates"] as $template_data){
			$this->CI->Templates_model->delete_template_by_gid($template_data["gid"]);
		}
	}

	function _arbitrary_installing() {
		// SEO
		$seo_data = array(
			'module_gid' => 'tell_friend',
			'model_name' => 'Tell_friend_model',
			'get_settings_method' => 'get_seo_settings',
			'get_rewrite_vars_method' => 'request_seo_rewrite',
			'get_sitemap_urls_method' => 'get_sitemap_xml_urls',
		);
		$this->CI->pg_seo->set_seo_module('tell_friend', $seo_data);
	}

	public function deinstall_site_map() {
		$this->CI->load->model('Site_map_model');
		$this->CI->Site_map_model->delete_sitemap_module('tell_friend');
	}
	
	/**
	 * Import module languages
	 * 
	 * @param array $langs_ids array languages identifiers
	 * @return void
	 */
	public function _arbitrary_lang_install($langs_ids=null){
		$langs_file = $this->CI->Install_model->language_file_read("tell_friend", "arbitrary", $langs_ids);
		if(!$langs_file){log_message("info", "Empty tell_friend arbitrary langs data"); return false;}
		
		$post_data = array(
			"title" => $langs_file["seo_tags_index_title"],
			"keyword" => $langs_file["seo_tags_index_keyword"],
			"description" => $langs_file["seo_tags_index_description"],
			"header" => $langs_file["seo_tags_index_header"],
			"og_title" => $langs_file["seo_tags_index_og_title"],
			"og_type" => $langs_file["seo_tags_index_og_type"],
			"og_description" => $langs_file["seo_tags_index_og_description"],
		);
		$this->CI->pg_seo->set_settings("user", "tell_friend", "index", $post_data);
	}

	/**
	 * Export module languages
	 * 
	 * @param array $langs_ids languages identifiers
	 * @return array
	 */
	public function _arbitrary_lang_export($langs_ids=null){
		if(empty($langs_ids)) return false;

		//// arbitrary
		$settings = $this->CI->pg_seo->get_settings("user", "tell_friend", "index", $langs_ids);
		$arbitrary_return["seo_tags_index_title"] = $settings["title"];
		$arbitrary_return["seo_tags_index_keyword"] = $settings["keyword"];
		$arbitrary_return["seo_tags_index_description"] = $settings["description"];
		$arbitrary_return["seo_tags_index_header"] = $settings["header"];
		$arbitrary_return["seo_tags_index_og_title"] = $settings["og_title"];
		$arbitrary_return["seo_tags_index_og_type"] = $settings["og_type"];
		$arbitrary_return["seo_tags_index_og_description"] = $settings["og_description"];

		return array("arbitrary" => $arbitrary_return);
	}

	function _arbitrary_deinstalling() {
		$this->CI->pg_seo->delete_seo_module('tell_friend');
	}
}