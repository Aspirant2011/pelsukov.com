<?php

$install_lang["header_tell_friend"] = "Рассказать другу";
$install_lang["tell_friend_settings_module"] = "Рассказать другу";
$install_lang["sett_tell_friend_item"] = "Рассказать другу";
$install_lang["tell_friend_refer_friend_price_field"] = "Плата за приглашеного друга";
$install_lang["subj"] = "Посмотри интересный сайт:[site]";
$install_lang["body"] = "<a href='[link]'>Перейди по этой ссылке!</a>";
$install_lang["text_tell_friend"] = "Приведи своих друзей на наш сайт и получи вознаграждение на свой счет за каждого зарегистрированного друга!<br/>Ты получишь 0.01 EUR на свой счет за каждого пользователя, которого ты привел!<br/>Отошли ссылку на сайт своему другу! Вы можете вставить несколько адресов, разделяя их ';'";
$install_lang["field_name"] = "Ваше Имя";
$install_lang["field_email"] = "Ваш Email";
$install_lang["field_to_email"] = "На email";
$install_lang["field_subject"] = "Тема";
$install_lang["field_message"] = "Сообщение";
$install_lang["field_captcha"] = "Защитный код";
$install_lang["error_message_incorrect"] = "Напишите сообщение";
$install_lang["error_no_recipients"] = "укажите email адреса получателей";
$install_lang["error_subject_incorrect"] = "Укажите тему письма";
$install_lang["error_email_incorrect"] = "Укажите свой email";
$install_lang["error_name_incorrect"] = "Укажите свое имя";
$install_lang["error_captcha_code_incorrect"] = "Неверный код с картинки";
$install_lang["success_send_form"] = "Сообщение отправлено, спасибо!";
