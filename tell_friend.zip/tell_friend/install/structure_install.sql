ALTER TABLE `[prefix]users`
ADD `tell_friend_code` varchar(50) COLLATE 'utf8_general_ci' NOT NULL AFTER `date_modified`,
COMMENT=''
REMOVE PARTITIONING;