<?php
/**
* Tell_friend controller
*
* @package PG_Dating
* @subpackage application
* @category	modules
* @copyright Pilot Group <http://www.pilotgroup.net/>
* @author Dmitry Popenov
* @version $Revision: 2 $ $Date: 2013-01-30 10:07:07 +0400 $
**/

class Tell_friend extends Controller {
	
	/**
	 * Constructor
	 */
	public function __construct() {
		parent::Controller();
	}
	
	public function index() {
	
		
		if($this->input->post('btn_send')){
			$post_data = array(
				"name" => $this->input->post('name', true),
				"email" => $this->input->post('email', true),
				"to_email" => $this->input->post('to_email', true),
				"subject" => $this->input->post('subject', true),
				"message" => $this->input->post('message', true),
				"captcha_confirmation" => $this->input->post('captcha_confirmation', true),
			);
			$this->load->model("Tell_friend_model");
			$validate_data = $this->Tell_friend_model->validate_form($post_data);

			if(!empty($validate_data["errors"])){
				$this->system_messages->add_message('error', $validate_data["errors"]);
				$data = $validate_data["data"];
			}else{
				$data = $validate_data["data"];
				$data['refer_block'] =  str_replace('[link]', site_url().'tell_friend/check/'.$this->Tell_friend_model->get_refer_code(intval($this->session->userdata('user_id'))), l('body', 'tell_friend'));
				$this->Tell_friend_model->send_contact_form($data);
				$this->system_messages->add_message('success', l('success_send_form', 'tell_friend'));
				redirect(site_url()."tell_friend");
			}
		}
		if (!isset($data)){
			$data['subject'] = str_replace('[site]', site_url(), l('subj', 'tell_friend'));
		}
		
		$refer_friend_price = $this->pg_module->get_module_config('tell_friend', 'refer_friend_price');
		$this->load->helper('payments');
		$refer_friend_price = currency_format(array('value'=>floatval($refer_friend_price)));
		$data['refer_friend_price_lang'] = str_replace('[amount]', $refer_friend_price, l('text_tell_friend', 'tell_friend'));
		
		$this->load->plugin('captcha');
		$this->config->load('captcha_settings');
		$captcha_settings = $this->config->item('captcha_settings');
		$captcha = create_captcha($captcha_settings);
		$_SESSION['captcha_word'] = $captcha['word'];
		$data['captcha_image'] = $captcha['image'];
		$data['captcha_word_length'] = strlen($captcha['word']);
		$this->template_lite->assign('data', $data);
		
		$this->template_lite->view('index');
	}
	
	public function check($refer_code=""){
		if (!empty($refer_code) && ($this->session->userdata('auth_type')!="user")){
			$_SESSION['refer_code'] = $refer_code;
			redirect(site_url()."users/registration");
		} else{
			redirect(site_url());
		}
	}
	
}