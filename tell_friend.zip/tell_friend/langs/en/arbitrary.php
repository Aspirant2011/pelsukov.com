<?php

$install_lang["seo_tags_index_description"] = "";
$install_lang["seo_tags_index_header"] = "Tell a friend";
$install_lang["seo_tags_index_keyword"] = "";
$install_lang["seo_tags_index_title"] = "Pilot Group: Tell a friend";