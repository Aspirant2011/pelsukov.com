<?php
$module['module'] = 'tell_friend';
$module['install_name'] = 'Tell friend module';
$module['install_descr'] = 'Tell friend module';
$module['version'] = '1.01';
$module['files'] = array(
	array('file', 'read', "application/modules/tell_friend/controllers/api_tell_friend.php"),
	array('file', 'read', "application/modules/tell_friend/controllers/tell_friend.php"),
	array('file', 'read', "application/modules/tell_friend/install/module.php"),
	array('file', 'read', "application/modules/tell_friend/install/permissions.php"),
	array('file', 'read', "application/modules/tell_friend/install/settings.php"),
	array('file', 'read', "application/modules/tell_friend/install/structure_deinstall.sql"),
	array('file', 'read', "application/modules/tell_friend/install/structure_install.sql"),
	array('file', 'read', "application/modules/tell_friend/models/tell_friend_install_model.php"),
	array('file', 'read', "application/modules/tell_friend/models/tell_friend_model.php"),
	array('file', 'read', "application/modules/tell_friend/views/default/index.tpl"),
	array('dir', 'read', 'application/modules/tell_friend/langs'),
);


$module['dependencies'] = array(
	'start'			=> array('version'=>'1.03'),
	'menu'			=> array('version'=>'1.01'),
	'notifications' => array('version'=>'1.03'),
);

$module['linked_modules'] = array(
	'install' => array(
		'menu'				=> 'install_menu',
		'site_map'			=> 'install_site_map',
		'banners'			=> 'install_banners',
		'notifications'		=> 'install_notifications',
	),
	'deinstall' => array(
		'menu'				=> 'deinstall_menu',
		'site_map'			=> 'deinstall_site_map',
		'banners'			=> 'deinstall_banners',
		'notifications'		=> 'deinstall_notifications',
	)
);