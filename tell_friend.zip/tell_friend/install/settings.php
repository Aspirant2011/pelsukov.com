<?php

$install_settings["refer_friend_price"] = "0.1";
