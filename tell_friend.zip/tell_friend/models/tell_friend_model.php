<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
* Mailbox Model
*
* @package PG_Dating
* @subpackage application
* @category	modules
* @copyright Pilot Group <http://www.pilotgroup.net/>
* @author Mikhail Chernov <mchernov@pilotgroup.net>
* @version $Revision: 2 $ $Date: 2010-04-02 15:07:07 +0300 (Ср, 02 апр 2010) $ $Author: mchernov $
**/

class Tell_friend_model extends Model
{
	/**
	 * Link to CodeIgniter object
	 * @var object
	 */
	private $CI;
	/**
	 * Constructor
	 *
	 * @return Tell_friendmodel object
	 */
	public function __construct(){
		parent::Model();
		$this->CI = & get_instance();
	}
	
	
	public function validate_form($data){
		$return = array("errors"=> array(), "data" => array());

		if(isset($data["name"])){
			$return["data"]["name"] = trim(strip_tags($data["name"]));

			if(empty($return["data"]["name"])){
				$return["errors"]['name'] = l('error_user_name_incorrect', 'tell_friend');
			}
		}

		if(isset($data["email"])){
			$return["data"]["email"] = trim(strip_tags($data["email"]));

			$this->CI->config->load('reg_exps', TRUE);
			$email_expr =  $this->CI->config->item('email', 'reg_exps');
			if(empty($return["data"]["email"]) || !preg_match($email_expr, $return["data"]["email"])){
				$return["errors"]['email'] = l('error_email_incorrect', 'tell_friend');
			}
		}

		if(isset($data["subject"])){
			$return["data"]["subject"] = trim(strip_tags($data["subject"]));

			if(empty($return["data"]["subject"])){
				$return["errors"]['subject'] = l('error_subject_incorrect', 'tell_friend');
			}
		}

		if(isset($data["message"])){
			$return["data"]["message"] = trim(strip_tags($data["message"]));

			if(empty($return["data"]["message"])){
				$return["errors"]['message'] = l('error_message_incorrect', 'tell_friend');
			}
		}

		if(isset($data["to_email"])){
			$return["data"]["to_email"] = trim(strip_tags($data["to_email"]));
			$mails = explode(';', $return["data"]["to_email"]);
			foreach ($mails as $key=>$mail){
				if(empty($mail) || !preg_match($email_expr, $mail)){
					unset($mails[$key]);
				}
			}
			if(empty($mails)){
				$return["errors"]['to_email'] = l('error_no_recipients', 'tell_friend');
			} else{
				$return["data"]["to_email_arr"] = $mails;
			}
			
		}

		if(isset($data["captcha_confirmation"])){
			$return["data"]["captcha_confirmation"] = trim(strip_tags($data["captcha_confirmation"]));

			if(empty($return["data"]["captcha_confirmation"]) || $return["data"]["captcha_confirmation"] != $_SESSION["captcha_word"]){
				$return["errors"]['captcha_confirmation'] = l('error_captcha_code_incorrect', 'tell_friend');
			}
		}

		return $return;
	}

	public function send_contact_form($data){
		$return = array("errors"=> array(), "data" => array());
		$lang_id = '';
		$this->CI->load->model('Notifications_model');

		foreach($data['to_email_arr'] as $mail){
			$send_data = $this->CI->Notifications_model->send_notification($mail, 'tell_a_friend', $data);
		}
	}

	public function get_refer_code($user_id){
		$this->CI->load->model('Users_model');
		$this->CI->Users_model->set_additional_fields(array('tell_friend_code'));
		$user = $this->CI->Users_model->get_user_by_id($user_id);
		$tell_friend_code = $user['tell_friend_code'];
		if (empty($tell_friend_code)){
			$tell_friend_code = substr(md5(time()),1,12);
			$user = $this->CI->Users_model->save_user($user_id, array('tell_friend_code'=>$tell_friend_code));
		}
		return $tell_friend_code;
	}

	public function update_user_account($refer_code){
		$this->CI->load->model('Users_model');
		$users = $this->CI->Users_model->get_users_list(null, null, null, array('where'=>array('tell_friend_code'=>$refer_code), 'fields'=>array('id')), array(), false);
		
		if (!empty($users[0]['id'])){
			$refer_friend_price = $this->CI->pg_module->get_module_config('tell_friend', 'refer_friend_price');
			$refer_id = $users[0]['id'];
			$account = $users[0]['account'];
			$new_account = floatval($account) + floatval($refer_friend_price);
			$this->CI->Users_model->save_user($refer_id, array('account'=>$new_account));
			
			$this->CI->load->model('Payments_model');
			$post_data = array(
				"payment_type_gid" => 'account',
				"id_user" => $refer_id,
				"amount" => $refer_friend_price,
				"currency_gid" => 'USD',
				"status" => '1',
				"system_gid" => l('header_tell_friend', 'tell_friend'),
				"payment_data" => serialize(array('name'=>l('header_tell_friend', 'tell_friend'))),
			);
			$payment_id = $this->CI->Payments_model->save_payment(null, $post_data);
		}
		/*$tell_friend_code = $user['tell_friend_code'];
		if (empty($tell_friend_code)){
			$tell_friend_code = substr(md5(time()),1,12);
			$user = $this->CI->Users_model->save_user($user_id, array('tell_friend_code'=>$tell_friend_code));
		}
		return $tell_friend_code;*/
	}
	

	public function get_seo_settings($method = '', $lang_id = '') {
		if (!empty($method)) {
			return $this->_get_seo_settings($method, $lang_id);
		} else {
			$actions = array('index');
			$return = array();
			foreach ($actions as $action) {
				$return[$action] = $this->_get_seo_settings($action, $lang_id);
			}
			return $return;
		}
	}

	private function _get_seo_settings($method, $lang_id = '') {
		switch($method){
			case 'index':
				return array(
					"templates" => array(),
					"url_vars" => array()
				); break;
		}
	}

	public function request_seo_rewrite($var_name_from, $var_name_to, $value) {
		if ($var_name_from == $var_name_to) {
			return $value;
		}
	}

	function get_sitemap_xml_urls(){
		$this->CI->load->helper('seo');
		$return = array();
		return $return;
	}

	function get_sitemap_urls(){
		$this->CI->load->helper('seo');
		$auth = $this->CI->session->userdata("auth_type");

		$block[] = array(
			"name" => l('header_tell_friend', 'tell_friend'),
			"link" => rewrite_link('tell_friend', 'index'),
			"clickable" => ($auth=="user"),
			"items" => array(
				array(
					"name" => l('header_tell_friend', 'tell_friend'),
					"link" => rewrite_link('tell_friend', 'write'),
					"clickable" => ($auth == "user"),
				),
			)
		);
		return $block;
	}
	/**
	 * Availables banners places (callback method)
	 * @return array
	 */
	public function _banner_available_pages(){
		$return[] = array('link' => 'tell_friend/index', 'name' => l('header_tell_friend', 'tell_friend'));
		return $return;
	}
}
