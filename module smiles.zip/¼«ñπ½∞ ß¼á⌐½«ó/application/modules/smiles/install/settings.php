<?php

$install_settings["use_smiles_comments"] = "1";
$install_settings["use_smiles_shoutbox"] = "1";
$install_settings["use_smiles_im"] = "1";
