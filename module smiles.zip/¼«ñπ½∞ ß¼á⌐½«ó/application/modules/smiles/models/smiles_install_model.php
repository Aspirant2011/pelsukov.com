<?php

/**
 * Smiles install model
 *
 * @package PG_DatingPro
 * @subpackage Smiles
 * @category	models
 * @copyright Pilot Group <http://www.pilotgroup.net/>
 * */
class Smiles_install_model extends Model {

	/**
	 * Link to Code Igniter object
	 * @param object
	 */
	protected $CI;

	/**
	 * Menu configuration
	 */
	protected $menu = array(
		
		'admin_menu' => array(
			'action' => 'none',
			'name' => 'Smiles section menu',
			'items' => array(
				'content_items' => array(
					'action'=>'none',
					'name' => '',
					'items' => array(
						"add_ons_items" => array(
							"action" => "none",
							'name' => '',
							"items" => array(
								"smiles_menu_item" => array("action" => "create", "link" => "admin/smiles", "status" => 1, "sorter" => 4),
							),
						),
					),
				),
			),
		),
		
		'admin_smiles_menu' => array(
			'action' => 'create',
			'name' => 'Smiles section menu',
			'items' => array(
				'smiles_list_item' => array('action' => 'create', 'link' => 'admin/smiles/', 'status' => 1, "sorter" => 1),
				'smiles_settings' => array('action' => 'create', 'link' => 'admin/smiles/settings', 'status' => 1, "sorter" => 2),
			),
		),
		
	);
	
	/**
	 * Ausers configuration
	 * @params
	 */
	protected $ausers = array(
		array('module' => 'smiles', 'method' => 'index', 'is_default' => 0),
	);
	
	
	/**
	 * Constructor
	 *
	 * @return Install object
	 */
	function smiles_install_model() {
		parent::Model();
		$this->CI = &get_instance();
		$this->CI->load->model("Install_model");
	}

	/**
	 * Install menu data
	 */
	public function install_menu() {
		$this->CI->load->helper('menu');
		foreach ($this->menu as $gid => $menu_data) {
			$this->menu[$gid]['id'] = linked_install_set_menu($gid, $menu_data['action'], $menu_data['name']);
			linked_install_process_menu_items($this->menu, 'create', $gid, 0, $this->menu[$gid]['items']);
		}
	}

	/**
	 * Install menu languages
	 */
	public function install_menu_lang_update($langs_ids = null) {
		if (empty($langs_ids)) {
			return false;
		}
		$langs_file = $this->CI->Install_model->language_file_read('smiles', 'menu', $langs_ids);

		if (!$langs_file) {
			log_message('info', 'Empty menu langs data');
			return false;
		}

		$this->CI->load->helper('menu');

		foreach ($this->menu as $gid => $menu_data) {
			linked_install_process_menu_items($this->menu, 'update', $gid, 0, $this->menu[$gid]['items'], $gid, $langs_file);
		}
		return true;
	}

	/**
	 * Export menu languages
	 */
	public function install_menu_lang_export($langs_ids) {
		if (empty($langs_ids)) {
			return false;
		}
		$this->CI->load->helper('menu');

		$return = array();
		foreach ($this->menu as $gid => $menu_data) {
			$temp = linked_install_process_menu_items($this->menu, 'export', $gid, 0, $this->menu[$gid]['items'], $gid, $langs_ids);
			$return = array_merge($return, $temp);
		}
		return array('menu' => $return);
	}

	/**
	 * Uninstall menu languages
	 */
	public function deinstall_menu() {
		$this->CI->load->helper('menu');
		foreach ($this->menu as $gid => $menu_data) {
			if ($menu_data['action'] == 'create') {
				linked_install_set_menu($gid, 'delete');
			} else {
				linked_install_delete_menu_items($gid, $this->menu[$gid]['items']);
			}
		}
	}

	/**
	 * Ausers module methods
	 */
	public function install_ausers() {
		// install ausers permissions
		$this->CI->load->model('Ausers_model');

		foreach ($this->ausers as $method) {
			$this->CI->Ausers_model->save_method(null, $method);
		}
	}

	/**
	 * Install ausers languages
	 */
	public function install_ausers_lang_update($langs_ids = null) {
		$langs_file = $this->CI->Install_model->language_file_read('smiles', 'ausers', $langs_ids);

		$this->CI->load->model('Ausers_model');
		$params['where']['module'] = 'smiles';
		$methods = $this->CI->Ausers_model->get_methods_lang_export($params);

		foreach ($methods as $method) {
			if (!empty($langs_file[$method['method']])) {
				$this->CI->Ausers_model->save_method($method['id'], array(), $langs_file[$method['method']]);
			}
		}
	}

	/**
	 * Export ausers languages
	 */
	public function install_ausers_lang_export($langs_ids) {
		$this->CI->load->model('Ausers_model');
		$params['where']['module'] = 'smiles';
		$methods = $this->CI->Ausers_model->get_methods_lang_export($params, $langs_ids);
		foreach ($methods as $method) {
			$return[$method['method']] = $method['langs'];
		}
		return array('ausers' => $return);
	}

	/**
	 * Uninstall ausers methods
	 */
	public function deinstall_ausers() {
		// delete moderation methods in ausers
		$this->CI->load->model('Ausers_model');
		$params['where']['module'] = 'smiles';
		$this->CI->Ausers_model->delete_methods($params);
	}
	
	/**
	 * Install uploads config smiles
	 * 
	 * @return void
	 */
	public function install_uploads () {
		// upload config
		$this->CI->load->model('uploads/models/Uploads_config_model');
		$config_data = array(
			'gid' => 'smiles',
			'name' => 'Smiles icon',
			'max_height' => 2500,
			'max_width' => 2500,
			'max_size' => 1024000, //1000 kb
			'name_format' => 'generate',
			'file_formats' => array('jpg', 'jpeg', 'gif', 'png'),
			'default_img' => '',
			'date_add' => date('Y-m-d H:i:s'),
		);
		$config_data['file_formats'] = serialize($config_data['file_formats']);
		$config_id = $this->CI->Uploads_config_model->save_config(null, $config_data);
		
		$thumb_data = array(
			'config_id' => $config_id,
			'prefix' => 'smiles',
			'width' => 24,
			'height' => 24,
			'effect' => 'none',
			'watermark_id' => 0,
			'crop_param' => 'crop',
			'crop_color' => 'ffffff',
			'date_add' => date('Y-m-d H:i:s'),
		);
		$this->CI->Uploads_config_model->save_thumb(null, $thumb_data);
	}
	
	/**
	 * De-install uploads config smiles
	 * 
	 * @return void
	 */
	public function deinstall_uploads () {
		$this->CI->load->model('uploads/models/Uploads_config_model');
		$config_data = $this->CI->Uploads_config_model->get_config_by_gid('smiles');
		if(!empty($config_data['id'])){
			$this->CI->Uploads_config_model->delete_config($config_data['id']);
		}
	}
	
		
}
