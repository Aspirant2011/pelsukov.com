DROP TABLE IF EXISTS `[prefix]smiles`;
CREATE TABLE `[prefix]smiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL DEFAULT '',
  `sorter` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `pg_smiles` (`id`, `name`, `sorter`) VALUES
(1,	'smileface.png',	1),
(2,	'smile.png',	2),
(3,	'winking.png',	3),
(4,	'laughing.png',	4),
(5,	'surprised.png',	5),
(6,	'happy.png',	6),
(7,	'sick.png',	7),
(8,	'angry.png',	8),
(9,	'blushing.png',	9),
(10,	'crying.png',	10),
(11,	'cool.png',	11),
(12,	'nerd.png',	12),
(13,	'sad.png',	13),
(14,	'tongue.png',	14);