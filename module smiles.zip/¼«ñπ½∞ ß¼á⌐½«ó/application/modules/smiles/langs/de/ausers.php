<?php
//en
$install_lang["index"] = "Smiles";
