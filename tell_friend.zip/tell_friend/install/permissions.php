<?php

$_permissions["tell_friend"]["check"] = "1";
$_permissions["tell_friend"]["index"] = "2";
$_permissions["api_tell_friend"]["index"] = "2";
