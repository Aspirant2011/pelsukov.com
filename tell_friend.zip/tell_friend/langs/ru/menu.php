<?php


$install_lang["user_top_menu_user-menu-communication_tell_friend_menu_item"] = "Рассказать другу";
$install_lang["user_top_menu_user-menu-communication_tell_friend_menu_item_tooltip"] = "";