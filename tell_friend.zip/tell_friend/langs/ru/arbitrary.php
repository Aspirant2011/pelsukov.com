<?php

$install_lang["seo_tags_index_description"] = "";
$install_lang["seo_tags_index_header"] = "Расказать друзьям";
$install_lang["seo_tags_index_keyword"] = "";
$install_lang["seo_tags_index_title"] = "Расказать друзьям";