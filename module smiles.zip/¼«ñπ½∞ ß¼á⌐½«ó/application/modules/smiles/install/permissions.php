<?php

$_permissions["admin_smiles"]["add"] = "3";
$_permissions["admin_smiles"]["ajax_confirm_delete_select"] = "3";
$_permissions["admin_smiles"]["ajax_delete_select"] = "3";
$_permissions["admin_smiles"]["ajax_save_sorter"] = "3";
$_permissions["admin_smiles"]["delete_smiles"] = "3";
$_permissions["admin_smiles"]["edit"] = "3";
$_permissions["admin_smiles"]["index"] = "3";
$_permissions["admin_smiles"]["post_upload"] = "3";
$_permissions["admin_smiles"]["remove"] = "3";
$_permissions["admin_smiles"]["settings"] = "3";
$_permissions["smiles"]["add"] = "2";
$_permissions["smiles"]["ajax_add"] = "2";
$_permissions["smiles"]["ajax_get_smiles"] = "2";
$_permissions["smiles"]["ajax_remove"] = "2";
$_permissions["smiles"]["index"] = "2";
$_permissions["smiles"]["my_smiles"] = "2";
$_permissions["smiles"]["remove"] = "2";
