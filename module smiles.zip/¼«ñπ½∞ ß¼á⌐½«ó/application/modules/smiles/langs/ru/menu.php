<?php
//ru
$install_lang["admin_menu_content_items_add_ons_items_smiles_menu_item"] = "Смайлы";
$install_lang["admin_menu_content_items_add_ons_items_smiles_menu_item_tooltip"] = "Загрузка и сортировка изображений";
$install_lang["admin_smiles_menu_smiles_list_item"] = "Список поцелуев";
$install_lang["admin_smiles_menu_smiles_settings"] = "Настройки";
$install_lang["user_top_menu_user-menu-communication_smiles_item"] = "Смайлы";
$install_lang["user_top_menu_user-menu-communication_smiles_item_tooltip"] = "Смайлы";
