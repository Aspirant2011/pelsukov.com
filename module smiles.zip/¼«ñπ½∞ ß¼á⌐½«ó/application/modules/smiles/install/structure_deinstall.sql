DROP TABLE IF EXISTS `[prefix]smiles`;
