<?php

if (!defined('BASEPATH')) {
	exit('No direct script access allowed');
}

define('SMILES_TABLE', DB_PREFIX . 'smiles');

/**
 * Kisses model
 * 
 * @package PG_DatingPro
 * @subpackage Kisses
 * @category	models
 * @copyright Pilot Group <http://www.pilotgroup.net/>
 * @developer Andrey Kopaev <akopaev@pilotgroup.net>
 * */
class Smiles_model extends Model {
	
	/**
	 * Link to Code Igniter object
	 */
	protected $CI;
	
	/**
	 * Table fields smiles
	 * @var array
	 */
	private $_fields_smiles = array(
		'id',
		'name',
		'sorter',
	);
	
	
	public $image_upload_gid = 'smiles';
	
	private $upload_config;
	
	private $moderation_type = "smiles";
	
	/**
	 * Constructor
	 *
	 * @return Smiles_model
	 */
	public function __construct() {
		parent::Model();
		$this->CI = & get_instance();
		$this->DB = &$this->CI->db;
		
		$this->CI->load->model('uploads/models/Uploads_config_model');
		$upload_config = $this->CI->Uploads_config_model->get_config_by_gid($this->image_upload_gid);
		$this->upload_config[$this->image_upload_gid] = $this->CI->Uploads_config_model->format_config($upload_config);
		
	}
	
	/**
	 * save smiles
	 * @param array $data
	 * @param integer $id
	 * @return bool
	 */
	public function save($id = null, $data) {
		
		if (is_null($id)) {
			
			
			$this->DB->insert(SMILES_TABLE, $data);
		} else {
			
			$this->DB->where('id', $id)
					->update(SMILES_TABLE, $data);
					
		}
		
		return true;
	}
	
	/**
	 * Return list smiles
	 * @param array $params
	 * @param integer $page
	 * @param integer $items_on_page
	 * @param array $order_by
	 * @param array $filter_object_ids
	 * @param array $filter_object_not_ids
	 * @return array
	 */
	public function get_list($page = 1, $items_on_page = 100, $params = array(), $order_by = array('sorter'=>'ASC'), $filter_object_ids = null, $filter_object_not_ids = null) {
		$this->DB->select(implode(', ', $this->_fields_smiles))->from(SMILES_TABLE);
		
		if (!empty($params['where']) && is_array($params['where']) && count($params['where'])) {
			foreach ($params['where'] as $field => $value) {
				$this->DB->where($field, $value);
			}
		}
		
		if (!empty($params['where_in']) && is_array($params['where_in']) && count($params['where_in'])) {
			foreach ($params['where_in'] as $field => $value) {
				$this->DB->where_in($field, $value);
			}
		}
		
		if (!empty($params['where_sql']) && is_array($params['where_sql']) && count($params['where_sql'])) {
			foreach ($params['where_sql'] as $value) {
				$this->DB->where($value, null, false);
			}
		}
		
		if (is_array($filter_object_ids) && count($filter_object_ids)) {
			$this->DB->where_in('id', $filter_object_ids);
		}
		
		if (is_array($filter_object_not_ids) && count($filter_object_not_ids)) {
			$this->DB->where_not_in('id', $filter_object_not_ids);
		}
		
		if (is_array($order_by) && count($order_by) > 0) {
			foreach ($order_by as $field => $dir) {
				if (in_array($field, $this->_fields_smiles)) {
					$this->DB->order_by($field . ' ' . $dir);
				}
			}
		}
		
		$page = intval($page);
		$items_on_page = intval($items_on_page);
		if (!empty($page) && $items_on_page>0) {
			$this->DB->limit($items_on_page, $items_on_page * ($page - 1));
		}
		$results = $this->DB->get()->result_array();
		return $results;
	}
	
	/**
	 * Return number of smiles
	 * @param array $params
	 * @return array
	 */
	public function get_count($params = array()) {
		if (isset($params['where']) && is_array($params['where']) && count($params['where'])) {
			foreach ($params['where'] as $field => $value) {
				$this->DB->where($field, $value);
			}
		}
		if (isset($params['where_in']) && is_array($params['where_in']) && count($params['where_in'])) {
			foreach ($params['where_in'] as $field => $value) {
				$this->DB->where_in($field, $value);
			}
		}
		if (isset($params['where_sql']) && is_array($params['where_sql']) && count($params['where_sql'])) {
			foreach ($params['where_sql'] as $value) {
				$this->DB->where($value, null, false);
			}
		}
		return $this->DB->count_all_results(SMILES_TABLE);
	}
	
	public function format($smiles) {
		
		return $smiles;
	}
	
	private function _get_upload_gid($file_name) {
		$extension = strtolower(end(explode('.', $file_name)));
		$result = '';
		
		foreach($this->upload_config as $upload_gid => $upload_config){
			foreach($upload_config['file_formats'] as $file_format){
				if($file_format == $extension){
					$result = $upload_gid;
					break 2;
				}
			}
		}
		return $result;
	}
	
	/**
	 * Method validate data
	 * @var $file_name
	 * @var $_POST
	 * return error or succes
	 */
	public function validate($file_name) {
		
		if(isset($_FILES[$file_name]) && is_array($_FILES[$file_name]) && !($_FILES[$file_name]["error"])){
			
			$upload_gid = $this->_get_upload_gid($_FILES[$file_name]['name']);
			
			if($upload_gid == $this->image_upload_gid){
				$this->CI->load->model("Uploads_model");
				$file_return = $this->CI->Uploads_model->validate_upload($this->image_upload_gid, $file_name);
				
				if(!empty($file_return["error"])){
					$validate_data["errors"][] = (is_array($file_return["error"])) ? implode("<br>", $file_return["error"]) : $file_return["error"];
				}
			}else{
				$validate_data["errors"][] = l('error_invalid_file_type', 'smiles');
			}
			
			$validate_data["data"]['mime'] = $_FILES[$file_name]["type"];
			
		}elseif(!empty($_FILES[$file_name]["error"])){
			$validate_data["errors"][] = $_FILES[$file_name]["error"];
		}
	}
	
	/**
	 * Method upload and save files
	 * @var $file_name
	 * @var $_POST
	 * return error or succes
	 */
	public function _post_upload($file_name) {
		
		$result = array();
		$data = array();
		
		$this->CI->load->model('Uploads_model');
		$upload_return = $this->CI->Uploads_model->upload($this->image_upload_gid, '', $file_name);
		//print_r($upload_return);
		//		exit;
					
					/*$thumb_data["crop_param"] = "resize";
					$thumb_data["width"] = 100;
					$thumb_data["height"] = 100;
					$thumb_data["effect"] = "";
					
					$return = $this->CI->Uploads_model->action('uploads/smiles-file/'.$upload_return['file'], $thumb_data, false);
					print_r($upload_return);
					exit;*/
					
		if(empty($upload_return['errors'])){
			$data['name'] = $upload_return['file'];
		} else {
			$result['errors'][] = $upload_return["errors"];
			return $result;
		}
		$result['is_saved'] = $this->_save_smiles($data, array());
		
		return $result;
	}
	
	/**
	 * Method upload and save files
	 * @var $file_name
	 * @var $_POST
	 * return error or succes
	 */
	private function _save_smiles($attrs, $where = array()){
		
		if(!empty($where) && is_array($where)){
			$this->DB->where($where)->update(SMILES_TABLE, $attrs);
			return $this->DB->affected_rows();
		}else{
			
			$this->DB->insert(SMILES_TABLE, $attrs);
			$return = $this->DB->insert_id();
			
			$this->DB->set('sorter', 'sorter + 1', FALSE);
			$this->DB->update(SMILES_TABLE);
			
			return $return;
		}
		
	}
	
	/**
	 * Method deleted smiles files
	 * @var $smiles_id integer smiles id
	 * return string
	 */
	public function delete_smiles($smiles_id){
		$result = array();
		
		$this->DB->where('id', $smiles_id);
		$this->DB->delete(SMILES_TABLE);
		/*$this->CI->load->model('Uploads_model');
		$result = $this->CI->Uploads_model->delete_upload($this->image_upload_gid, '', $smiles['name']);*/
		return true;
	}
	
	/**
	 * Method return info about smiles record
	 * @var $smiles_id integer smiles id
	 * return array
	 */
	function get_smiles_by_id($smiles_id) {
		
		if(!$smiles_id){
			return array();
		}
		
		$result = $this->DB->select(implode(", ", $this->_fields_smiles))->from(SMILES_TABLE)->where("id", $smiles_id)->get()->result_array();
		if(empty($result)){
			return array();
		}else{
			return $result[0];
		}
	}
	
	/**
	 * Validate smiles object for saving to data source
	 * 
	 * @param integer $smiles_id wish list identifier 
	 * @param array $data smiles data
	 * @return array
	 */
	public function validate_smiles($smiles_id, $data){
		$return = array('errors'=>array(), 'data'=>array());
		
		
		if(isset($data['id'])){
			$return['data']['id'] = intval($data['id']);
			if(empty($return['data']['id'])) unset($return['data']['id']);
		}
		
		if(!$data['object_id']){
			$return['errors'][] = l('error_invalid_user_to', 'smiles');
		} else {
			$return['data']['object_id'] = $data['object_id'];
		}
		
		$smiles = $this->get_smiles_by_id($smiles_id);
		
		if( empty($smiles) ){
			$return['errors'][] = l('error_empty_record', 'smiles');
		} else {
			$return['data']['smiles'] = $smiles;
		}
		
		if(!empty($data['message'])){
			
			$return['data']['message'] = mb_substr($data['message'], 0, $this->pg_module->get_module_config('smiles', 'number_max_symbols'), 'UTF-8');
			$this->CI->load->model('moderation/models/Moderation_badwords_model');
			$bw_count = $this->CI->Moderation_badwords_model->check_badwords($this->moderation_type, $return['data']['message'] );
			if($bw_count){
				$return["errors"][] = l('error_badwords_message', 'smiles');
			}
		}
		
		
		if(isset($data['date_created'])){
			$value = strtotime($data['date_created']);
			if($value > 0) $return['data']['date_created'] = date('Y-m-d', $value);
		}
		
		$default_lang_id = $this->CI->pg_language->current_lang_id;
		if(isset($data['name_'.$default_lang_id])){
			$return['data']['name_'.$default_lang_id] = trim(strip_tags($data['name_'.$default_lang_id]));
			if(empty($return['data']['name_'.$default_lang_id])){
				$return['errors'][] = l('error_empty_smiles_name', 'smiles');
			}else{				
				foreach($this->CI->pg_language->languages as $lid=>$lang_data){
					if($lid == $default_lang_id) continue;
					if(!isset($data['name_'.$lid]) || empty($data['name_'.$lid])){
						$return['data']['name_'.$lid] = $return['data']['name_'.$default_lang_id];
					}else{
						$return['data']['name_'.$lid] = trim(strip_tags($data['name_'.$lid]));
						if(empty($return['data']['name_'.$lid])){
							$return['errors'][] = l('error_empty_smiles_name', 'smiles');
							break;
						}
					}
				}
			}
		}
		
		return $return;
	}
	
	/**
	 * Save smiles object to data source
	 * 
	 * @param integer $smiles_id wish list identifier
	 * @param array $data wish list data
	 * @return integer
	 */
	public function save_smiles($smiles_id, $data){
		
		$this->DB->where('id', $smiles_id);
		$this->DB->update(SMILES_TABLE, $data);
		
		return $smiles_id;
	}
	
}
