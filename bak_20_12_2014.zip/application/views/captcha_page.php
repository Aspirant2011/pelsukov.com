<!DOCTYPE html>
<!--[if lt IE 8 ]><html class="no-js ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="no-js ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 8)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>
   <meta charset="utf-8">
	<title>Captcha module for PG sites from the web-developer Pavel Elsukov</title>
	<meta name="description" content="Captcha module for PG sites from the web-developer Paul Elsukov">
	<meta name="keywords" content="Pavel Elsukov,web-developer,engineer-developer,custom,site,development,php,html,js,jquery,web technology,web-engineer">

	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	
	<!-- Java Script
	================================================== -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="<?=base_url();?>application/views/js/jquery-1.10.2.min.js"><\/script>')</script>
	<script type="text/javascript" src="<?=base_url();?>application/views/js/jquery-migrate-1.2.1.min.js"></script>

	<script src="<?=base_url();?>application/views/js/jquery.flexslider.js"></script>
	<script src="<?=base_url();?>application/views/js/waypoints.js"></script>
	<script src="<?=base_url();?>application/views/js/jquery.fittext.js"></script>
	<script src="<?=base_url();?>application/views/js/magnific-popup.js"></script>
	<script src="<?=base_url();?>application/views/js/captcha_init.js"></script>

	<link rel="stylesheet" href="<?=base_url();?>application/views/css/default.css">
	<link rel="stylesheet" href="<?=base_url();?>application/views/css/captcha_layout.css">
	<link rel="stylesheet" href="<?=base_url();?>application/views/css/media-queries.css">
	<link rel="stylesheet" href="<?=base_url();?>application/views/css/magnific-popup.css">

	<script src="<?=base_url();?>application/views/js/modernizr.js"></script>

   <!-- recaptcha script
   ================================================== -->
	<script src='https://www.google.com/recaptcha/api.js'></script>
</head>

<body>


   <!-- About Section
   ================================================== -->
   <section id="about">

	<nav id="nav-wrap">

		<a class="mobile-btn" href="#nav-wrap" title="Show navigation">Show navigation</a>
		<a class="mobile-btn" href="#" title="Hide navigation">Hide navigation</a>

		<ul id="nav" class="nav">
			<li><a class="smoothscroll" href="#about">Description</a></li>
			<li><a class="smoothscroll" href="#gallery">Gallery</a></li>
			<li><a class="smoothscroll" href="#buy" style="color:red !important">Buy Now</a></li>
		</ul> <!-- end #nav -->

	</nav>

	<!-- end #nav-wrap -->
      <div class="row">

         <div class="three columns header-col">
            <img src="<?=base_url();?>application/views/images/portfolio/module_captcha/modals/image5_800x800.jpg"/>
         </div>

         <div class="nine columns main-col">

            <h2>Captcha module</h2>

            <p>Это полноценный Модуль для линейки продуктов компании <a href="http://pilotgroup.net" target="_blank">Pilot Group</a>. Он позволяет самостоятельно настраивать и менять капчу сайта по умолчанию. Его модульность означает, что любые изменения в самом модуле не потребуют дополнительных изменений в остальных разделах Вашего сайта.</p>
            <p>На сегодняшний день модуль включает в себя 1 включенную в продукт и 2 подключаемые каптчи для сайта, для каждой из которых возможна самостоятельная настройка внешнего вида:</p>
			<ul class="disc">
				<li><span>Включенная в Ваш скрипт каптча.</span> Для нее добавлена возможность задавать ширину и высоту капчи, а так же выбрать шрифт текста.</li>
				<li><span>Google recaptcha.</span> Сервис защиты от спама от google. Имеется возможность выбрать одну из четырех доступных тем, а так же выбрать язык, на котором будет она отображаться.</li>
				<li><span>Fully customized captcha.</span> Данная капча позволяет самостоятельно полностью настроить внешний вид капчи для сайта, поскольку включает в себя настойки размера, фоновой картинки, цвета, размера, стиля шрифта, набор символов, из которых будет составляться кодовое слова и еще некоторые другие настройки.</li>
			</ul>


         </div> <!-- end .main-col -->

      </div>
   </section> <!-- About Section End-->



   <!-- Portfolio Section--
   ================================================== -->
   <!-- Testimonials Section
   ================================================== -->
	<section id="gallery">

		<div class="text-container">

			<div class="row">
				<div class="two columns header-col"><h2 style="color:#fff">Gallery</h2></div>
				<div class="ten columns flex-container">
					

					<div class="flexslider">

						<ul class="slides">

							<li>
								<img src="<?=base_url();?>application/views/images/portfolio/module_captcha/image1.jpg">
							</li> <!-- slide ends -->
							<li>
								<img src="<?=base_url();?>application/views/images/portfolio/module_captcha/image2.jpg">
							</li> <!-- slide ends -->
							<li>
								<img src="<?=base_url();?>application/views/images/portfolio/module_captcha/image3.jpg">
							</li> <!-- slide ends -->
							<li>
								<img src="<?=base_url();?>application/views/images/portfolio/module_captcha/image4.jpg">
							</li> <!-- slide ends -->
							<li>
								<img src="<?=base_url();?>application/views/images/portfolio/module_captcha/image5.jpg">
							</li> <!-- slide ends -->

						</ul>

					</div> <!-- div.flexslider ends -->

				</div> <!-- div.flex-container ends -->

			</div> <!-- row ends -->

		</div>  <!-- text-container ends -->

	</section> <!-- Testimonials Section End-->

   <!-- Contact Section
   ================================================== -->
   <section id="buy">

		<div class="row section-head">

			<div class="two header-col">
				<h2>Buy now</h2>
			</div>

			<div class="ten">
				<p class="lead" style="margin:0;line-height:1">Покупая данный модуль, Вы получаете:</p>
				<ul class="disc">
					<li>Полноценный модуль для Вашего скрипта</li>
					<li>Бесплатную установку на Ваш сервер</li>
					<li>Возможность интегрировать любую другую понравившуюся Вам капчу не более, чем за один час</li>
				</ul>
			</div>

		</div>

         <div class="row">

            <div class="eight columns">

				<!-- form -->
				<form action="<?=base_url();?>buy" method="post" id="paydForm" name="paydForm">
					<input type="hidden" name="product" id="product" value="module_captcha">
					<input type="hidden" name="id_transaction" id="id_transaction" value="">
					<input type="hidden" name="payment_system" id="payment_system" value="">
					<fieldset>
						<div>
							<label for="script">Your script <span class="required">*</span></label>
							<select id="script" name="script">
								<option value="">Please select your PG script</option>
								<?php foreach ($products as $product){?>
								<option value="<?=$product['gid']?>"><?=$product['name']?></option>
								<?php }?>
							</select>
						</div>

						<div>
							<label for="name">Your Name <span class="required">*</span></label>
							<input type="text" value="" size="35" id="name" name="name">
						</div>

						<div>
							<label for="email">Your Email <span class="required">*</span></label>
							<input type="text" value="" size="35" id="email" name="email" placeholder="нужен для связи по вопросу установки">
						</div>

						<div>
							<label for="comment">Comment</label>
							<textarea cols="50" rows="7" id="comment" name="comment" placeholder="необязательно"></textarea>
						</div>

						<div class="payment_systems">
							<label for="comment">Payment system <span class="required">*</span></label>
							<i class="fa fa-cc-paypal fa-5x" system="paypal"></i>
							
						</div>

						<div style="margin:15px 0; overflow:hidden;">
							<label></label>
							<div class="g-recaptcha" data-sitekey="6LdmNP8SAAAAAFOowpjp7-lKHKew_NvsVZeyCJLc" style="float:left"></div>
						</div>

						<div>
							<button class="submit">Buy</button>
							<span id="image-loader">
							<img alt="" src="<?=base_url();?>application/views/images/loader.gif">
							</span>
						</div>

					</fieldset>
				</form> <!-- Form End -->

               <!-- contact-warning -->
               <div id="message-warning"> Error boy</div>
               <!-- contact-success -->
				   <div id="message-success">
                  <i class="fa fa-check"></i>Your message was sent, thank you!<br>
				   </div>

            </div>


			<aside class="four columns footer-widgets">

				<div class="widget widget_contact">

					<h4>Price information</h4>
					<p style="font-size: 75px; margin: 30px 0px; color: rgb(240, 96, 0);">$30</p>

				</div>

				<div class="widget widget_tweets">
					<h4 class="widget-title">Do you have a question?</h4>
					<a style="font-size: 20px;" href="<?=base_url();?>#contact" target="_blank"><i class="fa fa-envelope"></i>Contact Me</a>
				</div>

            </aside>

      </div>

   </section> <!-- Contact Section End-->


   <!-- footer
   ================================================== -->
	<footer>

		<div class="row">

			<div class="twelve columns">

				<ul class="copyright">
					<li>&copy; 2014 <a href="<?=base_url();?>" target="_blank">Pavel Elsukov</a></li> 
					<li>Design by <a title="Styleshout" href="http://www.styleshout.com/" target="_blank">Styleshout</a> and <a href="http://lab.yurbasik.org.ua/" target="_blank">lab</a></li>   
				</ul>

			</div>

			<div id="go-top"><a class="smoothscroll" title="Back to Top" href="#about"><i class="icon-up-open"></i></a></div>

		</div>

	</footer> <!-- Footer End-->

	<?php include('tracking.php');?>

</body>
</html>