<?php
//ru
$install_lang["index"] = "Смайлы";
