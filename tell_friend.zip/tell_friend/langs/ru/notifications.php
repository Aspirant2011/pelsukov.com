<?php

$install_lang["notification_tell_a_friend"] = "Рассказать другу";
$install_lang["tpl_tell_a_friend_content"] = "<p>[message]</p><br/><p>[refer_block]</p>";
$install_lang["tpl_tell_a_friend_subject"] = "[subject]";
