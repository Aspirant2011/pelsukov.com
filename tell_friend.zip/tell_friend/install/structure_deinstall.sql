ALTER TABLE `[prefix]users`
DROP `tell_friend_code`,
COMMENT=''
REMOVE PARTITIONING;