<?php

$install_lang["header_tell_friend"] = "Tell a friend";
$install_lang["tell_friend_settings_module"] = "Tell a friend";
$install_lang["sett_tell_friend_item"] = "Tell a friend";
$install_lang["tell_friend_refer_friend_price_field"] = "Refer friend price";
$install_lang["subj"] = "Please check interesting site:[site]";
$install_lang["body"] = "<a href='[link]'>Check this link!</a>";
$install_lang["text_tell_friend"] = "Refer us to your friend and get money on your account for each registered friend here!<br/>You get [amount] to your account for a new registered user referred by you!<br/>Send site link to your friend! You can specify more email addresses, separating them by ';' sign!";
$install_lang["field_name"] = "Your name";
$install_lang["field_email"] = "Your email";
$install_lang["field_to_email"] = "To email";
$install_lang["field_subject"] = "Subject";
$install_lang["field_message"] = "Message";
$install_lang["field_captcha"] = "Security code";
$install_lang["error_message_incorrect"] = "Please type your message";
$install_lang["error_no_recipients"] = "Please indicate recipient's email";
$install_lang["error_subject_incorrect"] = "Please add message subject";
$install_lang["error_email_incorrect"] = "Please indicate email";
$install_lang["error_name_incorrect"] = "Please indicate name";
$install_lang["error_captcha_code_incorrect"] = "Please enter security code";
$install_lang["success_send_form"] = "Message sent, thank you";