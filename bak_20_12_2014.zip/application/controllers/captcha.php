<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Captcha extends CI_Controller {

	public function index()
	{
		$this->load->model('scripts_model');
		$products = $this->scripts_model->get_product_by_module('module_captcha');
		$this->display_lib->assign('products', $products);
		
		$this->display_lib->view('captcha_page');
	}
}