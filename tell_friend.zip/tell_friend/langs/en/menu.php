<?php


$install_lang["user_top_menu_user-menu-communication_tell_friend_menu_item"] = "Tell a friend";
$install_lang["user_top_menu_user-menu-communication_tell_friend_menu_item_tooltip"] = "";